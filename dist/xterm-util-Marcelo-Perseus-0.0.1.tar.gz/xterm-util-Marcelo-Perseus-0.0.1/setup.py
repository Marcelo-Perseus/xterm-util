from setuptools import setup, find_packages

VERSION = '0.0.1'
DESCRIPTION = 'A package for customizing xterm more'
LONG_DESCRIPTION = 'A package used to customize xterm using escape sequences'

# Setting up
setup(
       # the name must match the folder name 'verysimplemodule'
        name="xterm-util-Marcelo-Perseus",
        version=VERSION,
        author="Marcelo Luciano",
        author_email="<Marcelo.Perseus@gmail.com>",
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        packages=find_packages(),
        install_requires=[],

        url="https://upload.pypi.org/",

        keywords=['python', 'xterm'],
        classifiers= [
            "Programming Language :: Python :: 3",
            "License :: OSI Approved :: MIT License",
            "Operating System :: POSIX :: Linux"
        ]
)
